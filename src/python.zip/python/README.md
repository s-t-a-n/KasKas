# real-time-live-streamlit-dashboard-python

Data Source used - https://github.com/Lexie88rus/bank-marketing-analysis

![image](https://user-images.githubusercontent.com/5347322/150425537-6d3cb9c8-764c-4c23-910c-395c520b28cb.png)
